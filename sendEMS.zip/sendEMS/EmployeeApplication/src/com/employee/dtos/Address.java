package com.employee.dtos;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity(name="address")
@Table(name="address2")
public class Address {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO , generator="AddressIdGenerator")
	@SequenceGenerator(name="AddressIdGenerator" , sequenceName="generate_address_id" , initialValue=10 , allocationSize=10)
	@Column
	private int id;
	
	@Column
	private String village;
	
	@Column
	private String city;
	
	@Column
	private String district;
	
	@Column
	private String state;
	
	@Column
	private long zipCode;
	
	@OneToMany(mappedBy="address" , cascade=CascadeType.ALL)
	private Set<Employee> employees ;
	
	public Address() {
		// TODO Auto-generated constructor stub
	}

	public Address(int id, String village, String city, String district,
			String state, long zipCode, Set<Employee> employees) {
		super();
		this.id = id;
		this.village = village;
		this.city = city;
		this.district = district;
		this.state = state;
		this.zipCode = zipCode;
		this.employees = employees;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getVillage() {
		return village;
	}

	public void setVillage(String village) {
		this.village = village;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public long getZipCode() {
		return zipCode;
	}

	public void setZipCode(long zipCode) {
		this.zipCode = zipCode;
	}

	public Set<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(Set<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public String toString() {
		return "Address [id=" + id + ", village=" + village + ", city=" + city
				+ ", district=" + district + ", state=" + state + ", zipCode="
				+ zipCode + ", employees=" + employees + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result
				+ ((district == null) ? 0 : district.hashCode());
		result = prime * result;
		result = prime * result + id;
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + ((village == null) ? 0 : village.hashCode());
		result = prime * result + (int) (zipCode ^ (zipCode >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (district == null) {
			if (other.district != null)
				return false;
		} else if (!district.equals(other.district))
			return false;
		if (employees == null) {
			if (other.employees != null)
				return false;
		} else if (!employees.equals(other.employees))
			return false;
		if (id != other.id)
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (village == null) {
			if (other.village != null)
				return false;
		} else if (!village.equals(other.village))
			return false;
		if (zipCode != other.zipCode)
			return false;
		return true;
	}
	
}
