package com.employee.services;

import com.employee.dtos.Employee;
import com.employee.dtos.User;
import com.employee.exceptions.EmployeeException;

public interface EmployeeService {

	public Employee addEmployee(Employee employee) throws EmployeeException;

	public User isValidUser(User user) throws EmployeeException;

	public Employee fetchEmployee(Employee employee) throws EmployeeException;

	public Employee updateEmployee(Employee employee) throws EmployeeException;

	public void deleteEmployee(Employee employee) throws EmployeeException;
}
