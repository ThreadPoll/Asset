package com.employee.daos;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.employee.dtos.Employee;
import com.employee.dtos.User;
import com.employee.exceptions.EmployeeException;

@Repository("employeeDAO")
public class EmployeeDAOImpl implements EmployeeDAO{
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Employee addEmployee(Employee employee) throws EmployeeException {
		entityManager.persist(employee);
		return employee;
	}

	@Override
	public User isValidUser(User user) throws EmployeeException {
		User user1 = entityManager.find(User.class, user.getUserId());
		if(user.equals(user1)){
			return user;
		}else{
			User user2 = new User();
			return user2;
		}
	}

	@Override
	public Employee fetchEmployee(Employee employee) throws EmployeeException {
		employee = entityManager.find(Employee.class, employee.getEmployeeId());
		return employee;
	}

	@Override
	public Employee updateEmployee(Employee employee) throws EmployeeException {
		return entityManager.merge(employee);
	}

	@Override
	public void deleteEmployee(Employee employee) throws EmployeeException {
		employee=entityManager.find(Employee.class, employee.getEmployeeId());
		entityManager.remove(employee.getAddress());
		entityManager.remove(employee);
	}

}
