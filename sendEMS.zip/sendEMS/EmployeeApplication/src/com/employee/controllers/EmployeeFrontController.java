package com.employee.controllers;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.employee.dtos.Employee;
import com.employee.dtos.User;
import com.employee.exceptions.EmployeeException;
import com.employee.services.EmployeeService;

@Controller
public class EmployeeFrontController {

	@Resource(name="employeeServices")
	EmployeeService employeeService;
	
	@RequestMapping("/index")					
	public String returnHomePage(){
		return "index";
	}
	
	@RequestMapping("/getLoginForm")
	public String getLoginForm(Model model){
		User user = new User();
		model.addAttribute("user", user);
		return "loginForm";
	}
	
	@RequestMapping("/login")
	public String login(@ModelAttribute User user , Model model){
		try {
			System.out.println("user1 is "+user);
			user = employeeService.isValidUser(user);
			System.out.println("user is "+user);
			if(user.getUserId()!=0){
				model.addAttribute("user", user);
				return "menu";
			}else{
				model.addAttribute("errorMessage", "Invalid Credential");
			}
		} catch (EmployeeException e) {
			e.printStackTrace();
		}
		return "loginForm";
	}
	
	@RequestMapping("/getAddEmployeeForm")
	public String getAddEmployeeForm(Model model){
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "addEmployee";
	}
	
	@RequestMapping("/addEmployee")
	public String addEmployee(@ModelAttribute Employee employee , Model model){
		try {
			employee = employeeService.addEmployee(employee);
			model.addAttribute(employee);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "postAddEmployee";
	}
	
	@RequestMapping("/getUpdateEmployeeForm")
	public String getUpdateEmployeeForm(Model model){
		Employee employee = new Employee();
		model.addAttribute(employee);
		return "updateEmployeeForm";
	}
	
	@RequestMapping("/fetchEmployee")
	public String fetchEmployee(@ModelAttribute Employee employee , Model model){
		try {
			employee=employeeService.fetchEmployee(employee);
			model.addAttribute("employee",employee);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "updateEmployeeForm";
	}
	
	@RequestMapping("/updateEmployee")
	public String updateEmployee(@ModelAttribute Employee employee , Model model){
		try {
			employee=employeeService.updateEmployee(employee);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "menu";
	}
	
	@RequestMapping("/getRemoveEmployeeForm")
	public String getRemoveEmployeeForm(Model model){
		Employee employee = new Employee();
		model.addAttribute(employee);
		return "deleteEmployeeForm";
	}
	
	@RequestMapping("/deleteEmployee")
	public String deleteEmployee(@ModelAttribute Employee employee , Model model){
		try {
			model.addAttribute("employee", employee);
			employeeService.deleteEmployee(employee);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "postDeleteEmployee";
	}
}
