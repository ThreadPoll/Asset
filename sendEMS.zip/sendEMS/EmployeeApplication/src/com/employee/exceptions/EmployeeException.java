package com.employee.exceptions;

public class EmployeeException extends Exception {

	public EmployeeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmployeeException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
